import java.io.*;
class KeyboardEvents implements Serializable{
	int code;
	KeyboardEvents(int code){
		this.code=code;
	}
	public void setKeyCode(int code){
		this.code=code;
	}
	public int getKeyCode(){
		return code;
	}
}
