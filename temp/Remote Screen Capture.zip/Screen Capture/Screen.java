import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.net.*;
import java.io.*;
class Screen extends JFrame{
	//	port no 143 for receiving images
	//	port no 365 for sending mouse events
	//	port no 333 for sending key events
	ServerSocket imgReceiver;
	Socket mouseEventSender;
	Socket keyboardEventSender;
	final JFrame frame;
	public static void main(String args[]){
		new Screen();
	}
	Screen(){
		super("Remote Access Server");
		frame=this;
		Container c=getContentPane();
		Toolkit t=Toolkit.getDefaultToolkit();
		Dimension d=t.getScreenSize();
		setBounds(d.width/4,d.height/4,d.width/2,(int)(d.height/3.5));
		setResizable(false);
		String s=System.getProperty("user.dir");
		Image img=t.createImage(s+"/Remote.jpg");
		c.add(new ImagePanel(img),BorderLayout.NORTH);
		JPanel center=new JPanel(new FlowLayout(FlowLayout.LEFT));
		center.add(new JLabel("Computer Name:"));
		final JTextField text=new JTextField(20);
		center.add(text);
		JPanel lower=new JPanel();
		final JButton connect,cancel;
		lower.add(connect=new JButton("Connect"));
		connect.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent a){		
				JOptionPane.showMessageDialog(frame,"Trying to connect "+text.getText()+"....");
				try{
					Socket s=new Socket(InetAddress.getByName(text.getText()),123);
				}catch(Exception e){}
				new ImageReceiver(frame,text.getText());
			}
		});
		lower.add(cancel=new JButton("Cance"));
		cancel.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent a){
				System.exit(0);
			}
		});
		c.add(center);
		c.add(lower,BorderLayout.SOUTH);
		addWindowListener(new WindowAdapter(){
			public void windowClosed(WindowEvent w){
				
			}
			public void windowClosing(WindowEvent w){
				System.exit(0);
			}
		});
		setVisible(true);
	}
}
class ImagePanel extends JPanel{
	Image img;
	ImagePanel(Image img){
		this.img=img;
		System.out.print("Image width="+img.getWidth(this));
		setPreferredSize(new Dimension(img.getWidth(this),img.getHeight(this)));
	}
	public void paint(Graphics g){
		super.paint(g);
		System.out.println("image drawn");
		g.drawImage(img,0,0,this);
	}
}
class ImageReceiver extends Window implements Runnable,MouseListener,MouseMotionListener{
	String clientName;
	ImageReceiver(Frame f,String n){
		super(f);
		addMouseListener(this);
		Toolkit toolkit=Toolkit.getDefaultToolkit();
		setSize(toolkit.getScreenSize());
		setBackground(Color.black);
		setVisible(true);
		Thread t=new Thread(this);
		t.start();
		clientName=n;
	}
	public void run(){
		try{
			ServerSocket s=new ServerSocket(143);
			while(true){
				Socket socket=s.accept();
	          		InputStream in=socket.getInputStream();
				ObjectInputStream ois=new ObjectInputStream(in);
				ImageIcon img=(ImageIcon)ois.readObject();
				Graphics g=getGraphics();
				img.paintIcon(this,g,0,0);
			}
		}catch(Exception e){System.out.println(e);}
	}

	public void mouseClicked(MouseEvent m){
		System.out.println("mouse clicked");
		sendPacket(new MouseEvents(m.getX(),m.getY(),m.getButton()));
	}
	public void mousePressed(MouseEvent m){
	}
	public void mouseReleased(MouseEvent m){

	}
	public void mouseEntered(MouseEvent m){
		
	}
	public void mouseExited(MouseEvent m){
	}
	public void mouseMoved(MouseEvent m){
		sendPacket(new MouseEvents(m.getX(),m.getY(),m.getButton()));
	}
	public void mouseDragged(MouseEvent m){
		sendPacket(new MouseEvents(m.getX(),m.getY(),m.getButton()));
	}
	private void sendPacket(MouseEvents m){
		try{
			InetAddress address=InetAddress.getByName(clientName);
			Socket s=new Socket(address,365);
			OutputStream out=s.getOutputStream(); 
			ObjectOutputStream oos=new ObjectOutputStream(out);
			oos.writeObject(m);
			oos.close();
			s.close();
		}catch(Exception e){System.out.println(e);}
	}
}